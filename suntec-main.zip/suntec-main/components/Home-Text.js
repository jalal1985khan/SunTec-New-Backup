import {Container} from 'react-bootstrap';

function LinksExample() {
  return (

<Container className="h_alert text-center p-3 mt-4">
<p className="fs-4">The World’s #1 Pricing and Billing Software
Creating value for enterprises through our Cloud-based products</p>
</Container>

  );
}

export default LinksExample;